﻿This code only includes the function declarations for the RPN calculator and its implemetnation as well. The testing is the only
thing left to complete.